#include <Book/Command.hpp>


Command::Command()
: action()
, category(Category::None)
{
}
